---
name: deepsearch-analytics
description: "DeepSearch API로 기업 스크리닝, 투자 전략 분석, 포트폴리오 구성을 수행합니다."
---

# DeepSearch 분석 & 투자 전략 스킬

기업 스크리닝, 투자 전략 분석, 포트폴리오 구성을 지원합니다.
KRX 업무(관리종목 후보 탐지, 재무위험 기업 스크리닝, 주가급변 원인분석)를 위한 스크리닝 기능을 포함합니다.

## Prerequisites

사용자에게 DeepSearch API 키를 요청하세요.

## 지원 기능

1. **재무 조건 스크리닝** - 매출, 영업이익률, 성장률 등 조건 조합
2. **분석 함수** - Top, Bottom, Sort, Rank, Max, Min, Mean, Sum, Select
3. **멀티팩터 스크리닝** - 복수 조건 AND/OR 조합
4. **뉴스+주가 결합 분석** - 특정 이벤트 발생 시 주가 변동 확인 (2단계 쿼리)
5. **가치투자 전략** - Graham, Buffett 등 방법론 적용
6. **적자전환/흑자전환 스크리닝** - 전용 스크립트로 2개년 비교

## Instructions

### Step 1: 분석 유형 결정

**A. 재무 조건 스크리닝:**
```
매출 > 1000000000000                              → 매출 1조 이상
영업이익 / 매출 > 0.15                             → 영업이익률 15% 이상
2023 매출 > 2022 매출 * 1.5                       → 전년대비 매출 50% 이상 성장
매출 > 1000000000000 and 영업이익 / 매출 > 0.15   → 복합 조건
설립일 > 2020-01-01                               → 2020년 이후 설립
대표이사 나이 > 70                                  → CEO 나이 조건
```

**KRX 업무 - 재무위험 기업 스크리닝:**
```
영업이익 < 0 and 매출 > 500000000000              → 영업적자 대형 상장기업 (152개)
자본 < 0 and 매출 > 10000000000                   → 자본잠식 우려 기업 (1,567개)
부채 / 자본 > 5 and 매출 > 100000000000           → 고부채비율 기업 (512개)
```

**B. 분석 함수:**
```
Top(매출액, 10)                    → 매출 상위 10개 기업
Top(영업이익, 20)                  → 영업이익 상위 20개 기업
Sort(매출액 > 1000000000000, ascending=False) → 매출 1조 이상 기업 정렬
Max(삼성전자 매출액 2015-2024)     → 삼성전자 최대 매출액
Mean(삼성전자 종가 2024-01-01-2024-12-31) → 평균 종가
```

**C. 기업 발굴 + 재무 결합:**
```
("반도체" 관련 기업) and (매출액 영업이익)
("전기차" 관련 기업) and (매출 영업이익 당기순이익)
(매출 영업이익) in ("건강기능식품" 산업 기업)
```

**D. 뉴스+주가 결합 분석 (2단계):**
1단계: 뉴스 검색으로 이벤트 날짜/기업 확인
2단계: 해당 기업의 주가 데이터 별도 조회
(재무/시장 데이터와 문서 데이터는 업데이트 주기가 달라 별도 조회 필요)

**E. 가치투자 스크리닝:**

**Benjamin Graham 기준:**
```
매출 > 1000000000000 and 영업이익 / 매출 > 0.1 and 당기순이익 > 0
```
→ 이후 개별 기업에 대해 PER, PBR 확인: `삼성전자 PER`, `삼성전자 PBR`

**Warren Buffett 기준:**
```
매출 > 1000000000000 and 영업이익 / 매출 > 0.15
```
→ 높은 영업이익률 기업 필터 후 `GetFinancialStatements`로 5년간 이익 지속성 확인

**포트폴리오 수익률 시뮬레이션 (2단계):**
1단계: 조건으로 기업 리스트 추출
2단계: 각 기업의 기간별 종가 조회하여 수익률 계산
```
삼성전자 SK하이닉스 LG전자 종가 2023-01-01-2023-12-31
```

**F. 적자전환/흑자전환 스크리닝:**

영업이익 기준 전년대비 부호 전환 기업을 검출합니다. (전용 스크립트 사용)

```bash
# 적자전환 (2023 흑자 → 2024 적자), 매출 5000억 이상
python {baseDir}/scripts/turnaround_screener.py "API_KEY" loss 5000

# 흑자전환 (2023 적자 → 2024 흑자), 매출 1000억 이상
python {baseDir}/scripts/turnaround_screener.py "API_KEY" profit 1000
```

**원리:** API 한계로 `영업이익`의 연도간 비교 쿼리(`2024 영업이익 < 0 and 2023 영업이익 > 0`)가 불가능하여, 2단계 자동화 방식:
1. `상장 기업 and 영업이익 < 0 (또는 > 0)` → 현재 적자(흑자) 기업 추출
2. 각 기업별 `GetFinancialStatements(기업명, report_ids="Income", date_from=2023-01-01, date_to=2024-12-31)` → 전년 부호 확인

### Step 2: 쿼리 생성 및 실행

```bash
python {baseDir}/scripts/query_api.py "API_KEY" "쿼리"
```

**복합 분석은 여러 쿼리를 순차 실행:**
1. 스크리닝 쿼리로 기업 리스트 추출
2. 추출된 기업들의 데이터 조회: 재무제표 → `GetFinancialStatements`, 주가 → 자연어 쿼리
3. 결과 종합하여 분석

### Step 3: 결과 포맷팅

**스크리닝 결과:**
```
## 스크리닝 결과 (N개 기업)

| 기업명 | 종목코드 | 매출액 | 영업이익률 |
|--------|---------|--------|-----------|
| ... | ... | ... | ... |
```

**포트폴리오 분석:**
```
## 포트폴리오 수익률 분석

기간: YYYY-MM-DD ~ YYYY-MM-DD
전략: [전략 설명]

| 기업명 | 시작가 | 종가 | 수익률 |
|--------|--------|------|--------|
| ... | ... | ... | ... |

평균 수익률: X%
```

### 주의사항

- 재무데이터(연/분기)와 시장데이터(일별)는 업데이트 주기가 달라 별도 쿼리 필요
- 기업명이 도시명 등과 혼동될 수 있으면 반드시 따옴표("") 사용
- Top() 함수에 복잡한 관련기업 쿼리를 직접 넣으면 실패할 수 있음 → 2단계로 분리

## 이 스킬이 커버하지 않는 DeepSearch 기능

이 스킬은 **기업 스크리닝 & 투자 전략 분석** 전문입니다. 아래 기능이 필요하면 다른 스킬이나 DeepSearch API 문서를 안내하세요.

**다른 스킬로 처리 가능:**
| 요청 유형 | 안내할 스킬 |
|-----------|-----------|
| 뉴스/공시/리서치 문서 검색, 감성분석, 트렌드 | **deepsearch-docs** 스킬 |
| 기업 상세정보, 배당, 주주/임원, 컨센서스 | **deepsearch-finance** 스킬 |

**DeepSearch API에는 있으나 현재 스킬에 미포함:**
| API 함수 | 설명 | 용도 예시 |
|---------|------|----------|
| FindEntityByShareholderName | 주주명으로 기업 검색 | "국민연금이 주주인 기업 목록" |
| FindEntityByIndustryID | 산업분류코드로 기업 검색 | "특정 KSIC 코드 기업" |
| FindEntityByBusinessArea | 사업영역으로 기업 검색 | "전기차 사업 기업 목록" |
| FindEntityByAddress | 주소로 기업 검색 | "판교 소재 기업" |
| FindAssociatedEntity | 주제 관련도 기업 검색 | "AI와 관련도 높은 기업" |
| GetCompanyRelatedFirms | 관계사 정보 | "삼성전자 자회사/관계사" |
| GetConglomerateFinancialStatements | 그룹 재무제표 | "삼성그룹 전체 재무" |
| GetAggregateIndustryInfo | 산업별 집계 | "반도체 산업 전체 매출 합계" |
| GetMarketSummaryInfoByIndustry | 산업별 시장 요약 | "산업별 시가총액/PER 비교" |

**fallback 응답 템플릿:**
사용자 질문이 이 스킬의 범위 밖이지만 DeepSearch API로 가능한 경우:
> "이 요청은 제가 현재 학습한 스크리닝/분석 스킬의 범위 밖입니다. 하지만 DeepSearch API의 `{함수명}` 기능으로 처리할 수 있습니다.
> - 관련 API 문서: DeepSearch API 마스터 가이드 (docs/DEEPSEARCH_API_MASTER.md)
> - 추가 스킬이 필요하시면 해당 기능을 포함한 스킬을 생성할 수 있습니다."

## Resources

분석 함수 가이드: [{baseDir}/references/analytics_guide.md](references/analytics_guide.md)
검증된 사용 사례: [{baseDir}/references/verified_examples.md](references/verified_examples.md)
가치투자 방법론: [{baseDir}/references/value_investing.md](references/value_investing.md)
